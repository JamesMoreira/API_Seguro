USE [Seguro]
GO

CREATE TABLE [dbo].[ParamCalculo](
	[IdParamCalculo] [int] IDENTITY(1,1) NOT NULL,
	[PercMargemSeguranca] [numeric](10,4) NOT NULL,
	[PercLucro] [numeric](10,4) NOT NULL,
	[Ativo] [bit] NOT NULL,
	[DataAtualizacao] [datetime] NOT NULL,
 CONSTRAINT [PK_ParamCalculo] PRIMARY KEY CLUSTERED 
(
	[IdParamCalculo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO ParamCalculo (PercMargemSeguranca, PercLucro, Ativo, DataAtualizacao) Values (3, 5, 1, GETDATE());
