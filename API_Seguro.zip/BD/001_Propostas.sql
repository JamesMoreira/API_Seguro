USE [Seguro]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Propostas](
	[IdProposta] [int] IDENTITY(1,1) NOT NULL,
	[Placa] [varchar] (07) NOT NULL,
	[Marca] [varchar] (50) NOT NULL,
	[Modelo] [varchar](50) NOT NULL,
	[CPF] [varchar] (11) NOT NULL,
	[Nome] [varchar] (50) NOT NULL,
	[Idade] [int] NOT NULL,
	[ValorVeiculo] [numeric](15,2) NOT NULL,
	[TaxaRisco] [numeric](15,2) NOT NULL,
	[PremioRisco] [numeric](15,2) NOT NULL,
	[PremioPuro] [numeric](15,2) NOT NULL,
	[PremioComercial] [numeric](15,2) NOT NULL,
	[DataAtualizacao] [datetime] NOT NULL,
 CONSTRAINT [PK_Propostas] PRIMARY KEY CLUSTERED 
(
	[IdProposta] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
