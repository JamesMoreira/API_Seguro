using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain.Models;

namespace Infra.Data.Mappings
{    
    public class PropostasMap : IEntityTypeConfiguration<Propostas>
    {
        public void Configure(EntityTypeBuilder<Propostas> builder)
        {
            builder.HasKey(x => x.IdProposta);
        }
    }
}
