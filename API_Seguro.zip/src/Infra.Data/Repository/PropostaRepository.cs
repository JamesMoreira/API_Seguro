﻿using Dapper;
using Domain.Filter;
using Domain.Interfaces;
using Domain.Models;
using Domain.Summary;
using Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infra.Data.Repository
{
    public class PropostaRepository : IPropostaRepository
    {
        protected readonly DBContext _applicationDbContext;

        public PropostaRepository(DBContext context) 
        {
            _applicationDbContext = context;
        }
        public async Task<ParamCalculo> GetParam()
        {
            try
            {
                Console.WriteLine(" Acessando banco de dados ");

                var entity = await _applicationDbContext
                    .Parametros
                    .Where(x => x.Ativo == true)
                    .FirstAsync();

                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao consultar banco de dados  ", ex.Message);
                throw ex;
            }
        }
        public async Task<List<Propostas>> GetProposal(PropostaFilter filter)
        {
            try
            {

                string aux = " Where ";

                var sql = "Select IdProposta, Placa, Marca, Modelo, CPF, Nome, Idade, ValorVeiculo, TaxaRisco, PremioRisco, PremioPuro, PremioComercial, DataAtualizacao From Propostas";

                if ((filter.IdProposta ?? 0) > 0)
                {
                    sql = sql + aux + $" IdProposta = {filter.IdProposta}";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.Placa))
                {
                    sql = sql + aux + $" Placa Like '%{filter.Placa.Trim()}%";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.Marca))
                {
                    sql = sql + aux + $" Marca Like '%{filter.Marca.Trim()}%";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.Modelo))
                {
                    sql = sql + aux + $" Modelo Like '%{filter.Modelo.Trim()}%";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.CPF))
                {
                    sql = sql + aux + $" CPF Like '%{filter.CPF.Trim()}%";
                    aux = " And ";
                }
                if (!string.IsNullOrEmpty(filter.Nome))
                {
                    sql = sql + aux + $" Nome Like '%{filter.Nome.Trim()}%";
                    aux = " And ";
                }

                sql += $" Order by IdProposta Desc";

                var entity = await _applicationDbContext.Propostas.FromSqlRaw(sql).ToListAsync();

                return entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao consultar banco de dados  ", ex.Message);
                throw ex;
            }
        }
        public async Task<bool> AddProposalAsync(Propostas proposta)
        {
            try
            {
                string sql = $"Insert into Propostas (Placa, Marca, Modelo, CPF, Nome, Idade, ValorVeiculo, TaxaRisco, PremioRisco, PremioPuro, PremioComercial, DataAtualizacao) values (";
                sql += $"'{proposta.Placa}', '{proposta.Marca}', '{proposta.Modelo}', '{proposta.CPF}', '{proposta.Nome}', {proposta.Idade}, {proposta.ValorVeiculo.ToString().Replace(",", ".")}, {proposta.TaxaRisco.ToString().Replace(",",".")}, {proposta.PremioRisco.ToString().Replace(",", ".")}, {proposta.PremioPuro.ToString().Replace(",", ".")}, {proposta.PremioComercial.ToString().Replace(",", ".")}, GETDATE());";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao incluir Proposta ", ex.Message);
                return false;
            }
        }
        public async Task<bool> DeleteProposalAsync(int idProposta)
        {
            try
            {
                string sql = $"Delete from Propostas Where IdProposta = {idProposta};";
                var result = await _applicationDbContext.Database.ExecuteSqlRawAsync(sql);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Erro ao excluir Proposta ", ex.Message);
                return false;
            }
        }
    }
}
