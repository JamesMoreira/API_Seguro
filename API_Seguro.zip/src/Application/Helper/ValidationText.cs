﻿using System;

namespace Application.Helper
{
    public static class ValidationText
    {
        public static string ValidarTexto(string texto, int? tamanho)
        {
            string result = "";

            if ((texto == null) || (texto.Length == 0))
            {
                return result;
            }

            int qtdeLetras = 255;
            if (tamanho != null)
            {
                qtdeLetras = (int)tamanho;
            }
            try
            {
                result = "";
                texto = texto.ToUpper().Trim().Replace("SELECT","").Replace("UPDATE","").Replace("DELETE","").Replace("LIKE","").Replace("INSERT","");
                for (int ii = 0; ii < texto.Length; ii++)
                {
                    int aux1 = Convert.ToChar(texto.Substring(ii, 1));
                    if ((aux1 >= 32) && (aux1 <= 126) && (aux1 != 39) && (aux1 != 92) && (aux1 != 94) && (aux1 != 96)) 
                    {
                        result = result + texto.Substring(ii, 1);
                    }
                    else
                    {
                        result = result + " ";
                    }
                }
                result = result.Replace("  ", " ").Trim();
                if (result.Length >= qtdeLetras)
                {
                    result = result.Substring(0, qtdeLetras);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }
    }
}
