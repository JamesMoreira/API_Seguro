﻿namespace Application.ViewModels
{
    public class UsuarioViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public long Cpf { get; set; }
        public string Email { get; set; }
        public int StatusUsuarioId { get; set; }
        public string? Password { get; set; }

        public string AspNetUser { get; set; }
    }
}
