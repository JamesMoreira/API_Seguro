﻿using System.ComponentModel.DataAnnotations;

namespace Application.ViewModels
{
    public class PropostaInsert
    {
        [Required(ErrorMessage = "Placa é obrigatória!")]
        public string Placa { get; set; }
        [Required(ErrorMessage = "Marca do Veículo é obrigatória!")]
        public string Marca { get; set; }
        [Required(ErrorMessage = "Modelo do Veículo é obrigatório!")]
        public string Modelo { get; set; }
        [Required(ErrorMessage = "CPF do Segurado é obrigatório!")]
        public string CPF { get; set; }
        [Required(ErrorMessage = "Nome do Segurado é obrigatório!")]
        public string Nome { get; set; }
        [Required(ErrorMessage = "Idade do Segurado é obrigatória!")]
        public int Idade { get; set; }
        [Required(ErrorMessage = "Valor do Veículo é obrigatório!")]
        public decimal ValorVeiculo { get; set; }
    }
    public class PropostaDelete
    {
        [Required(ErrorMessage = "Id da Proposta precisa ser informado!")]
        public int IdProposta { get; set; }
    }
}
