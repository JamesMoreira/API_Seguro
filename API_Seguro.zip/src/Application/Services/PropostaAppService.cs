﻿using System;
using System.Threading.Tasks;
using Application.Interfaces;
using Microsoft.Extensions.Logging;
using Application.ViewModels;
using Domain.Filter;
using Domain.Interfaces;
using AutoMapper;
using System.Data;
using Domain.Models;
using Domain.Summary;
using Application.Helper;
using System.Collections.Generic;

namespace Application.Services
{
    public class PropostaAppService : IPropostaAppService
    {
        private readonly ILogger<IPropostaAppService> _logger;
        private readonly IPropostaRepository _appRepository;
        private readonly IMapper _mapper;

        public PropostaAppService(ILogger<IPropostaAppService> logger, 
            IPropostaRepository appRepository, 
            IMapper mapper)
        {
            _logger = logger;
            _appRepository = appRepository;
            _mapper = mapper;
        }
        public async Task<ProposalReportSummary> GetPropostas(PropostaFilter filter)
        {
            filter.Placa = ValidationText.ValidarTexto(filter.Placa, 7);
            filter.Marca = ValidationText.ValidarTexto(filter.Marca, 50);
            filter.Modelo = ValidationText.ValidarTexto(filter.Modelo, 50);
            filter.Nome = ValidationText.ValidarTexto(filter.Nome, 50);
            filter.CPF = ValidationText.ValidarTexto(filter.CPF, 11);

            decimal TotalValorVeiculo = 0;
            decimal TotalTaxaRisco = 0;
            decimal TotalPremioRisco = 0;
            decimal TotalPremioPuro = 0;
            decimal TotalPremioComercial = 0;

            ProposalReportSummary result = new ProposalReportSummary();
            result.Propostas = new List<Propostas>();

            var entity = await _appRepository.GetProposal(filter);

            if (entity != null && entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    TotalValorVeiculo += item.ValorVeiculo;
                    TotalTaxaRisco += item.TaxaRisco;
                    TotalPremioRisco += item.PremioRisco;
                    TotalPremioPuro += item.PremioPuro;
                    TotalPremioComercial += item.PremioComercial;
                    result.Propostas.Add(item);
                }
                result.QtdeLinhas = entity.Count;
                result.ValorVeiculo = (TotalValorVeiculo / entity.Count);
                result.TaxaRisco = (TotalTaxaRisco / entity.Count);
                result.PremioRisco = (TotalPremioRisco / entity.Count);
                result.PremioPuro = (TotalPremioPuro / entity.Count);
                result.PremioComercial = (TotalPremioComercial / entity.Count);
            }

            return result;
        }
        public async Task<DataTable> GetPropostasReports(PropostaFilter filter)
        {
            filter.Placa = ValidationText.ValidarTexto(filter.Placa, 7);
            filter.Marca = ValidationText.ValidarTexto(filter.Marca, 50);
            filter.Modelo = ValidationText.ValidarTexto(filter.Modelo, 50);
            filter.Nome = ValidationText.ValidarTexto(filter.Nome, 50);
            filter.CPF = ValidationText.ValidarTexto(filter.CPF, 11);
            var result = await _appRepository.GetProposal(filter);

            decimal TotalValorVeiculo = 0;
            decimal TotalTaxaRisco = 0;
            decimal TotalPremioRisco = 0;
            decimal TotalPremioPuro = 0;
            decimal TotalPremioComercial = 0;

            DataTable data = new DataTable();
            data.TableName = "Relatório de Propostas de Seguros de Veículos";
            data.Columns.Add("Id da proposta", typeof(int));
            data.Columns.Add("Placa", typeof(string));
            data.Columns.Add("Marca do Veículo", typeof(string));
            data.Columns.Add("Modelo do Veículo", typeof(string));
            data.Columns.Add("CPF", typeof(string));
            data.Columns.Add("Nome do Segurado", typeof(string));
            data.Columns.Add("Idade", typeof(int));
            data.Columns.Add("Valor do Veículo", typeof(float));
            data.Columns.Add("Taxa de Risco", typeof(float));
            data.Columns.Add("Prêmio de Risco", typeof(float));
            data.Columns.Add("Prêmio Puro", typeof(float));
            data.Columns.Add("Prêmio Comercial", typeof(float));
            data.Columns.Add("Data de Atualização", typeof(string));

            if (result != null && result.Count > 0)
            {
                foreach(var item in result)
                {
                    TotalValorVeiculo += item.ValorVeiculo;
                    TotalTaxaRisco += item.TaxaRisco;
                    TotalPremioRisco += item.PremioRisco;
                    TotalPremioPuro += item.PremioPuro;
                    TotalPremioComercial += item.PremioComercial;

                    data.Rows.Add(item.IdProposta, item.Placa, item.Marca, item.Modelo, item.CPF, item.Nome, item.Idade, item.ValorVeiculo, item.TaxaRisco, item.PremioRisco, item.PremioPuro, item.PremioComercial, item.DataAtualizacao.ToString("dd/MM/yyyy"));
                }
                data.Rows.Add();
                data.Rows.Add(0,0,0,0,0,0,0,(TotalValorVeiculo / result.Count), (TotalTaxaRisco / result.Count), (TotalPremioRisco / result.Count), (TotalPremioPuro / result.Count), (TotalPremioComercial / result.Count));
            }

            return data;
        }
        public async Task<bool> AddPropostas(PropostaInsert dados)
        {
            try
            {
                decimal percMargemSeguranca = 0;
                decimal percLucro = 0;

                var param = await _appRepository.GetParam();

                if (param == null)
                {
                    Console.WriteLine($"Não foram encontrados os parametros de Cálculo");
                    return false;
                }

                try
                {
                    percMargemSeguranca = 1 + (param.PercMargemSeguranca / 100);
                    percLucro = 1 + (param.PercLucro / 100);
                }
                catch (Exception ex) 
                {
                    Console.WriteLine($"Não foram encontrados os parametros de Cálculo");
                    return false;
                }

                Propostas propostas = new Propostas();
                propostas.Placa = dados.Placa;
                propostas.Marca = dados.Marca;
                propostas.Modelo = dados.Modelo;
                propostas.CPF = dados.CPF;
                propostas.Nome = dados.Nome;
                propostas.Idade = dados.Idade;
                propostas.ValorVeiculo = dados.ValorVeiculo;
                propostas.TaxaRisco = 0;
                if (dados.ValorVeiculo > 0)
                {
                    propostas.TaxaRisco = ((dados.ValorVeiculo * 5) / (dados.ValorVeiculo * 2));
                }
                propostas.PremioRisco = ((dados.ValorVeiculo * propostas.TaxaRisco) / 100);
                propostas.PremioPuro = propostas.PremioRisco * percMargemSeguranca;
                propostas.PremioComercial = propostas.PremioPuro * percLucro;

                var result = await _appRepository.AddProposalAsync(propostas);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao incluir Proposta : {ex.Message}");
                return false;
            }
        }
        public async Task<bool> DeletePropostas(PropostaDelete dados)
        {
            try
            {
                var result = await _appRepository.DeleteProposalAsync(dados.IdProposta);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($" Erro ao excluir Proposta : {ex.Message}");
                return false;
            }
        }
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
