﻿using System;
using System.Data;
using System.Threading.Tasks;
using Application.ViewModels;
using Domain.Filter;
using Domain.Summary;

namespace Application.Interfaces
{
    public interface IPropostaAppService : IDisposable
    {
        public Task<ProposalReportSummary> GetPropostas(PropostaFilter filter);
        public Task<DataTable> GetPropostasReports(PropostaFilter filter);
        public Task<bool> AddPropostas(PropostaInsert dados);
        public Task<bool> DeletePropostas(PropostaDelete dados);
    }
}
