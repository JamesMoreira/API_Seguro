﻿using AutoMapper;
using Domain.Models;

namespace Application.AutoMapper
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public DomainToViewModelMappingProfile()
        {
            CreateMap<Propostas, Propostas>()
                .ForMember(dest => dest.IdProposta,
                opt => opt.MapFrom(src => src.IdProposta));
        }
    }
}
