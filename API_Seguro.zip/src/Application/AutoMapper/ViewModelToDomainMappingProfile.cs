﻿using AutoMapper;
using Domain.Models;

namespace Application.AutoMapper
{
    public class ViewModelToDomainMappingProfile : Profile
    {
        public ViewModelToDomainMappingProfile()
        {
            CreateMap<Propostas, Propostas>()
                .ConstructUsing(c => new Propostas());
        }
    }
}
