﻿using ClosedXML.Excel;
using Application.Interfaces;
using Application.ViewModels;
using Domain.Filter;
using Infra.CrossCutting.IoC.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Services.Api.Controllers
{
    [Route("api-seguro")]
    public class PropostaController : ControllerBase
    {
        private readonly IPropostaAppService _appService;
        private readonly ILogger<PropostaController> _logger;

        public PropostaController(IPropostaAppService apoliceAppService, ILogger<PropostaController> logger)
        {
            _appService = apoliceAppService;
            _logger = logger;
        }

        [HttpGet("propostas")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> Filter(PropostaFilter dados)
        {
            Console.WriteLine(" Recebendo requisição Propostas");

            try
            {
                var result = await _appService.GetPropostas(dados);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpGet("propostas-reports")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), 400)]
        public async Task<IActionResult> PropostasReports(PropostaFilter dados)
        {
            try
            {
                var fileName = $"Propostas_{DateTime.Now.ToString("yyyyMMdd_HHmmss")}.xlsx";
                Console.WriteLine(" Recebendo requisição Propostas");

                XLWorkbook wb = new XLWorkbook();
                wb.Worksheets.Add(await _appService.GetPropostasReports(dados), "Propostas");
                wb.SaveAs($"files/{fileName}");

                var filePath = $"files/{fileName}"; // get file full path based on file name
                if (!System.IO.File.Exists(filePath))
                {
                    return BadRequest();
                }

                return File(await System.IO.File.ReadAllBytesAsync(filePath), "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                return BadRequest("Informações não encontradas");
            }
        }

        [HttpPost("propostas-incluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> Incluir([FromBody] PropostaInsert dados)
        {
            try
            {
                string mensagem = "Proposta incluida com sucesso";

                if (dados == null)
                {
                    return BadRequest("Dados precisam ser informados!");
                }

                if (dados.Idade <= 0)
                {
                    return BadRequest("Idade precisa ser informada");
                }

                if (dados.ValorVeiculo <= 0)
                {
                    return BadRequest("Valor do veículo precisa ser informado ");
                }

                if (await _appService.AddPropostas(dados) == false)
                {
                    return BadRequest("Erro ao incluir a Proposta");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao incluir a Proposta");
            }
        }

        [HttpPost("propostas-excluir")]
        [Authorize(Roles = UserRoles.User + "," + UserRoles.Admin)]
        public async Task<IActionResult> Excluir([FromBody] PropostaDelete dados)
        {
            try
            {
                string mensagem = "Proposta excluída com sucesso";

                if (dados == null)
                {
                    return BadRequest("Id precisa ser informado");
                }

                if (dados.IdProposta <= 0)
                {
                    return BadRequest("Id precisa ser informado");
                }

                var filtros = new PropostaFilter();
                filtros.IdProposta = dados.IdProposta;
                var result = await _appService.GetPropostas(filtros);

                if (result.QtdeLinhas == 0)
                {
                    return BadRequest("Proposta não encontrada !");
                }

                if (await _appService.DeletePropostas(dados) == false)
                {
                    return BadRequest("Erro ao excluir os dados da Proposta");
                }

                return Ok(mensagem);
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao excluir os dados da Proposta");
            }
        }
    }
}
