﻿using Domain.Filter;
using Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IPropostaRepository
    {
        public Task<ParamCalculo> GetParam();
        public Task<List<Propostas>> GetProposal(PropostaFilter filter);
        public Task<bool> AddProposalAsync(Propostas proposta);
        public Task<bool> DeleteProposalAsync(int idProposta);

    }
}
