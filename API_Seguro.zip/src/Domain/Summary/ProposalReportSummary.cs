﻿using Domain.Models;
using System.Collections.Generic;

namespace Domain.Summary
{
    public class ProposalReportSummary
    {
        public List<Propostas> Propostas { get; set; }
        public int QtdeLinhas { get; set; }
        public decimal ValorVeiculo { get; set; }
        public decimal TaxaRisco { get; set; }
        public decimal PremioRisco { get; set; }
        public decimal PremioPuro { get; set; }
        public decimal PremioComercial { get; set; }
    }
}
