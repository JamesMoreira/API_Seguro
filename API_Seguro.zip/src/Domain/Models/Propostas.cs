﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Models
{
    [Table("Propostas")]
    public class Propostas
    {
        public int IdProposta {  get; set; }
        public string Placa { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string CPF { get; set; }
        public string Nome { get; set; }
        public int Idade { get; set; }
        public decimal ValorVeiculo { get; set; }
        public decimal TaxaRisco { get; set; }
        public decimal PremioRisco { get; set; }
        public decimal PremioPuro { get; set; }
        public decimal PremioComercial { get; set; }
        public DateTime DataAtualizacao { get; set; }
    }
}
