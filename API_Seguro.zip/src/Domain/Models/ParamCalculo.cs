﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Models
{
    [Table("ParamCalculo")]
    public class ParamCalculo
    {
        public int IdParamCalculo { get; set; }
        public decimal PercMargemSeguranca { get; set; }
        public decimal PercLucro { get; set; }
        public bool Ativo { get; set; }
        public DateTime DataAtualizacao { get; set; }
    }
}
