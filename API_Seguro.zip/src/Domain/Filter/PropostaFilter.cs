﻿namespace Domain.Filter
{
    public class PropostaFilter
    {
        public int? IdProposta { get; set; }
        public string Placa { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string CPF { get; set; }
        public string Nome { get; set; }
    }
}
