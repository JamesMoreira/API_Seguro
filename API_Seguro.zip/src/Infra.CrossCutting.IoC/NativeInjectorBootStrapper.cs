﻿using Application.Interfaces;
using Application.Services;
using Domain.Interfaces;
using Infra.Data.Context;
using Infra.Data.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Infra.CrossCutting.IoC
{
    public static class NativeInjectorBootStrapper
    {
        public static void RegisterServices(IServiceCollection services)
        {
            // Application
            services.AddScoped<IPropostaAppService, PropostaAppService>();

            // Infra - Data
            services.AddScoped<IPropostaRepository, PropostaRepository>();
            services.AddScoped<DBContext>();
            services.AddTransient<DBContext>();
        }
    }
}